def make_ends(nums):
    return([nums[0], nums[len(nums)-1]])