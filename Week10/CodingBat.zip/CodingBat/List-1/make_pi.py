def make_pi():
    pi = []
    pi.append(3)
    pi.append(1)
    pi.append(4)
    return (pi)