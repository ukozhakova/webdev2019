def double_char(str):
    return ''.join(char * 2 for char in str)