def cat_dog(str):
    return str.count('cat') == str.count('dog')