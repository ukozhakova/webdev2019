def diff21(n):
    if n>21:
        return 2*(int(n-21))
    else:
        return int(21-n)

