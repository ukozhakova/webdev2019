def string_times(str, n):
  s = ""
  for i in range(n):
    s+=str
  return s
